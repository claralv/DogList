package com.example.doglist

data class DogsResponse(var status: String, var message: List<String>)

